class Aluno:Pessoa
{
    private int mat;
    private string curso;
    
    public void setMat(int mat){
        this.mat = mat;
    }
    public int getMat(){
        return mat;
    }
    
    public void setCurso(string curso){
        this.curso = curso;
    }
    public string getCurso(){
        return curso;
    }
}